#!/usr/bin/env bash
set -euo pipefail
echo "Installing prerequisites..."
sudo apt-get update
sudo apt-get install -y build-essential cmake git libpcap-dev libquickfix-dev libboost-all-dev python3-venv
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip pytest wheel aiohttp websockets fastapi uvicorn
echo "Done."
