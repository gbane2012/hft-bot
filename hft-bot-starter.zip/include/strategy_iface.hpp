#pragma once
#include <cstdint>
#include <string>

struct Tick {
    uint64_t ts;        // epoch ns
    char     side;      // 'B', 'A', 'T'
    double   price;
    int32_t  qty;
};

class Strategy {
public:
    virtual void on_init() = 0;
    virtual void on_tick(const Tick& t) = 0;
    virtual void on_order_ack(const std::string& id) = 0;
    virtual void on_order_reject(const std::string& id, int err) = 0;
    virtual ~Strategy() = default;
};

extern "C" Strategy* create_strategy();
