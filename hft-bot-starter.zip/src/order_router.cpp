#include <iostream>
int main() {
    std::cout << "order_router stub running\n";
    return 0;
}
